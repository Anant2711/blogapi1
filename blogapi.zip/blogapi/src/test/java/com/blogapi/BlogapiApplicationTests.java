package com.blogapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
